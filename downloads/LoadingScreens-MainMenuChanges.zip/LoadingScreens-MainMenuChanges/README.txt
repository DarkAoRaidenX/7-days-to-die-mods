Name of Mod
A20 - Version 1.00
Description and Updates


⚡______________________________________________________________________________________________________________________⚡
README TABLE OF CONTENTS
1. About Author
2. Mod Philosophy
3. Features
4. Updates
 - Bugs
5. Wish List

⚡_____________________________________________________________________________________________________________________⚡
1.  ABOUT AUTHOR
	-Name - DarkAoRaidenX
	-Started playing 7d2d during Alpha 18
	-Started attempting to mod in Alpha 19
	-First published a mod during Alpha 19
	-Where to find:
		Discord Name - DarkAoRaidenX#6672
		https://discord.gg/UccyzVm5Xq - My Streaming Discord.

		https://7daystodiemods.com/
		https://www.nexusmods.com/users/96342523?tab=user+files
		https://www.twitch.tv/DarkAoRaidenX
		
		
⚡______________________________________________________________________________________________________________________⚡
2.  MOD PHILOSOPHY (Taken from AuroraGiggleFairy - The Best/My Favorite HUD mod maker.)
	-Singeplayer AND/OR Server-Side!
	-Goal: Enhance Vanilla Gameplay!
	-Feedback and Testing is Beneficial!
	-Detailed Notes for Individual Preference and Mod Learning!
	
	"The best mods rely on community involvement."
	
	
⚡______________________________________________________________________________________________________________________⚡
3.  Features
	*First, if you run into any conflicts, you may contact DarkAoRaidenX via discord: https://discord.gg/UccyzVm5Xq or DarkAoRaidenX#6672

This mod adds 8 new pictures to the loading screen and changes the Main Menu background.

To add more 
Replace the files in the "bgs" folder and name them the same 1-8 or main-menu. File type should be jpg. 


⚡______________________________________________________________________________________________________________________⚡
4. Updates



⚡______________________________________________________________________________________________________________________⚡
5.  Wish List

