Traders Have More Quests And Range
A20 - Version 1.00
Description and Updates


⚡______________________________________________________________________________________________________________________⚡
README TABLE OF CONTENTS
1. About Author
2. Mod Philosophy
3. Features
4. Updates
 - Bugs
5. Wish List

⚡_____________________________________________________________________________________________________________________⚡
1.  ABOUT AUTHOR
	-Name - DarkAoRaidenX
	-Started playing 7d2d during Alpha 18
	-Started attempting to mod in Alpha 19
	-First published a mod during Alpha 19
	-Where to find:
		Discord Name - DarkAoRaidenX#6672
		Discord (Streaming) - https://discord.gg/UccyzVm5Xq.
		https://darkaoraidenx.github.io/
		https://7daystodiemods.com/
		https://www.nexusmods.com/users/96342523?tab=user+files
		https://www.twitch.tv/DarkAoRaidenX
		
		
⚡______________________________________________________________________________________________________________________⚡
2.  MOD PHILOSOPHY (Taken from AuroraGiggleFairy - The Best/My Favorite HUD mod maker.)
	-Singeplayer AND/OR Server-Side!
	-Goal: Enhance Vanilla Gameplay!
	-Feedback and Testing is Beneficial!
	-Detailed Notes for Individual Preference and Mod Learning!
	
	"The best mods rely on community involvement."
	
	
⚡______________________________________________________________________________________________________________________⚡
3.  Features
	*First, if you run into any conflicts or need help, you may contact DarkAoRaidenX via discord: https://discord.gg/UccyzVm5Xq or DarkAoRaidenX#6672

!WARNING - RUNS WITH EAC OFF!

This mod makes it so Traders Have more Quests in their list and also increases the range of possible locations. It increases the distance check to 1500 and 2000 meters. This mod was possible because of Bowa(Bowabb) and the .dll file they created. I thank them for creating it and allowing me to make a modlet out it!

As of right now they are 3 versions 10,15 and 20 Quests. You also can either choose from the default quest list on the Right of the screen or the Left hand of the screen.

Bowabb - Mods
https://www.nexusmods.com/7daystodie/users/154686173

⚡______________________________________________________________________________________________________________________⚡
4. Updates



⚡______________________________________________________________________________________________________________________⚡
5.  Wish List

1. For this to be possible with XML only!