Quick Tips

I tried to add the most common .xmls people use 
but if there is one that you want to edit just copy and paste an .xml file and name it to whatever.

Vanilla Files is 
Steam\steamapps\common\7 Days To Die\Data

Mod's folder goes in %appdata% > 7 Days To Die 
- If there is no Mods folder make it exactly Mods. 

Mod folder structure

ModFolderName (Main Folder)
- Config (Folder)
 - XUi (Folder) (Only needed for UI)
 - XUi_Common (Folder) (Only needed for UI)
 - XUi_Menu (Folder) (Only needed for UI)
- UIAtlases (only needed for icons)
- ModInfo.xml

- Mods need a ModInfo.xml to work
- UIAtlases > ItemIconAtlas folders is for Custom Icons. Name the image the same name as what the item is in the code. The image is .png and 160x160.


XML Files 

You can name the name open and closed tags whatever you want.
The most common I have seen people's Username, config, 
or what i do i name it after the XML i am editing.

<configs>

The codes go between in the open and closed tag

</configs>

or

<recipes>

The codes go between in the open and closed tag

</recipes>


Localization (English Only Code)
Key,Source
NameOfWhatever,Name of Whatever,


Config Dump
- To troubleshoot you can first see if it applies in the world. 
Roaming\7DaysToDie\Saves\RandomGenName\Name\ConfigsDump
- Open the .xml file you're trying to edit and search for what you're trying to change.